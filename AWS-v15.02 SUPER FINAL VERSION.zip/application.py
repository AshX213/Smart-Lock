from flask import *
import bcrypt
import sqlite3
import sys
import os
sys.path.append("/opt/python/current/app/application")
application = Flask (__name__)
application.secret_key = os.urandom(12)

conn=sqlite3.connect("login_management.db", check_same_thread=False)
c = conn.cursor()

# Kelvin, Use This Link: http://127.0.0.1:5000/?beaconid=0bad1f66ca2237d6f4afe723e2758a3d
# http://smart-lock-env.us-east-2.elasticbeanstalk.com/?beaconid=0bad1f66ca2237d6f4afe723e2758a3d
@application.route("/")
def home():
    c.execute('''SELECT open FROM login WHERE deviceid=? LIMIT 1''', (request.args.get('beaconid'),))
    data = c.fetchone()
    print('H', data[0])
    return str(int(data[0]) == 1)


@application.route("/app_login", methods=['POST']) #GET requests will be blocked
def json_example():

    req_data = request.form

    retrieved_username = req_data['username']
    retrieved_password = req_data['password'].encode('utf-8')
    retrieved_deviceid = req_data['beaconid']
    deviceopen = req_data['open']
    print(retrieved_username, retrieved_password, retrieved_deviceid, deviceopen)

    c.execute('''SELECT password FROM login WHERE username = ?''', (retrieved_username,))
    hashed = c.fetchone()[0].encode('utf-8')
    print(hashed)
    # Hash a password for the first time, with a randomly-generated salt
    if bcrypt.checkpw(retrieved_password, hashed):
        # Check that a unhashed password matches one that has previously been hashed
        print("It Matches!")
        c.execute(
            '''UPDATE login SET open = ? WHERE username = ? AND deviceid = ?''',
            (deviceopen, retrieved_username, retrieved_deviceid))

        print(deviceopen)
        conn.commit()
        return '''
                   The Username is: {}
                   The DeviceID is: {}
                   DeviceOpen is: {}'''.format(retrieved_username, retrieved_deviceid, deviceopen)

    else:
        print("It Does not Match :(")




if __name__ == "__main__":
        # application.run(debug=True, host="127.0.0.1", port=5000)
        application.run()


#For next version, make it save the last 10 passwords
#This would become the next token list that the Raspberry Pi will see
#Setting up HTTPS
#http://www.howto-expert.com/how-to-get-https-setting-up-ssl-on-your-websi

